import React, { createContext, useContext, useState, useRef } from 'react';
import type { ReactNode } from 'react';

export type SceneState = 
  | 'hero'
  | 'finance'
  | 'stock'
  | 'microplastics'
  | 'vision'
  | 'resume'
  | 'contact';

export interface HighFrequencyState {
  pointer: { x: number; y: number };
  scrollVelocity: number;
  scrollProgress: number;
}

interface SceneContextProps {
  sceneState: SceneState;
  setSceneState: (state: SceneState) => void;
  activeProjectIndex: number;
  setActiveProjectIndex: (index: number) => void;
  hfState: React.MutableRefObject<HighFrequencyState>;
}

const SceneContext = createContext<SceneContextProps | null>(null);

export function SceneProvider({ children }: { children: ReactNode }) {
  const [sceneState, setSceneState] = useState<SceneState>('hero');
  const [activeProjectIndex, setActiveProjectIndex] = useState(0);
  
  // High-frequency state held in a ref to avoid re-renders during rAF/mousemove
  const hfState = useRef<HighFrequencyState>({
    pointer: { x: 0, y: 0 },
    scrollVelocity: 0,
    scrollProgress: 0
  });

  return (
    <SceneContext.Provider value={{
      sceneState,
      setSceneState,
      activeProjectIndex,
      setActiveProjectIndex,
      hfState
    }}>
      {children}
    </SceneContext.Provider>
  );
}

export function useSceneStore() {
  const context = useContext(SceneContext);
  if (!context) {
    throw new Error('useSceneStore must be used within a SceneProvider');
  }
  return context;
}

export type NavigationTheme = 'light' | 'dark' | 'cobalt';

export function useNavigationTheme(): NavigationTheme {
  const { sceneState } = useSceneStore();
  
  switch (sceneState) {
    case 'hero':
    case 'finance':
    case 'stock':
    case 'vision':
    case 'contact':
      return 'dark'; // Dark theme means the background is dark, so text should be light
    case 'microplastics':
    case 'resume':
      return 'light'; // Light theme means the background is light, so text should be dark
    default:
      return 'dark';
  }
}

