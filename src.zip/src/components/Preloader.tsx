import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface PreloaderProps {
  onComplete?: () => void;
}

export default function Preloader({ onComplete }: PreloaderProps) {
  const [done, setDone] = useState(false);

  useEffect(() => {
    const alreadyBooted = typeof window !== 'undefined' && sessionStorage.getItem('boot-shown');
    const delay = alreadyBooted ? 200 : 600;

    const timer = setTimeout(() => {
      if (typeof window !== 'undefined') sessionStorage.setItem('boot-shown', '1');
      setDone(true);
      onComplete?.();
    }, delay);

    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <AnimatePresence>
      {!done && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.4, ease: 'easeInOut' }}
          className="fixed inset-0 z-[300] flex items-center justify-center bg-[var(--bg)]"
        >
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
            className="flex items-center space-x-3 font-mono text-xs text-[var(--text-muted)] uppercase tracking-widest"
          >
            <span className="w-2 h-2 rounded-full bg-[var(--primary)] animate-ping" />
            <span>VEDANT SHUKLA // 2026</span>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
