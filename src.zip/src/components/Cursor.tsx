export default function Cursor() {
  // Cursor disabled entirely during Phase 1 of the Creative Reset.
  // We will reintroduce a highly specific, minimal annotation cursor only after 
  // the project scenes and WebGL media canvas are fully mature and immersive.
  return null;
}
