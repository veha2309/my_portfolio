import { useRef, useEffect, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import gsap from 'gsap';
import { useSceneStore } from '../../store/useSceneStore';

// Vertex Shader: simple pass-through
const vertexShader = `
  varying vec2 vUv;
  void main() {
    vUv = uv;
    gl_Position = vec4(position, 1.0);
  }
`;

// Fragment Shader: Smooth gradient and noise interpolation based on scene state
const fragmentShader = `
  varying vec2 vUv;
  uniform float uTime;
  uniform vec3 uColor1;
  uniform vec3 uColor2;
  uniform float uDistortion;
  uniform vec2 uPointer;

  // Simple pseudo-random noise function
  float hash(vec2 p) {
    return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453123);
  }

  void main() {
    // Basic gradient field
    vec2 p = vUv;
    
    // Add subtle distortion based on time and uniform
    p.x += sin(p.y * 3.0 + uTime * 0.5) * uDistortion;
    p.y += cos(p.x * 2.0 + uTime * 0.3) * uDistortion;
    
    // Pointer influence
    float dist = distance(vUv, uPointer * 0.5 + 0.5);
    p += (uPointer - vUv) * 0.05 * (1.0 - smoothstep(0.0, 0.5, dist));

    float mixVal = smoothstep(0.0, 1.0, p.y + p.x * 0.5);
    
    vec3 color = mix(uColor1, uColor2, mixVal);
    
    // Add fine grain
    float noise = hash(vUv * 500.0 + uTime);
    color += (noise - 0.5) * 0.04;
    
    gl_FragColor = vec4(color, 1.0);
  }
`;

// Scene Theme definitions
const SCENE_THEMES: Record<string, { c1: string; c2: string; dist: number }> = {
  hero: { c1: '#050505', c2: '#101525', dist: 0.1 },
  finance: { c1: '#000820', c2: '#002580', dist: 0.05 },
  stock: { c1: '#11151a', c2: '#2a3b4c', dist: 0.15 },
  microplastics: { c1: '#e6ebed', c2: '#b8c5cc', dist: 0.08 },
  vision: { c1: '#0f0a1c', c2: '#301b50', dist: 0.2 },
  resume: { c1: '#f2f0ea', c2: '#e5e1d8', dist: 0.02 },
  contact: { c1: '#0A0A0B', c2: '#001A80', dist: 0.3 },
};

function FullScreenPlane() {
  const materialRef = useRef<THREE.ShaderMaterial>(null);
  const { sceneState, hfState } = useSceneStore();
  
  // Convert hex to THREE.Color objects for the shader
  const uniforms = useMemo(() => {
    const theme = SCENE_THEMES['hero'];
    return {
      uTime: { value: 0 },
      uColor1: { value: new THREE.Color(theme.c1) },
      uColor2: { value: new THREE.Color(theme.c2) },
      uDistortion: { value: theme.dist },
      uPointer: { value: new THREE.Vector2(0, 0) }
    };
  }, []);

  // Animate uniforms smoothly when sceneState changes
  useEffect(() => {
    if (!materialRef.current) return;
    const theme = SCENE_THEMES[sceneState] || SCENE_THEMES['hero'];
    const targetC1 = new THREE.Color(theme.c1);
    const targetC2 = new THREE.Color(theme.c2);
    
    gsap.to(materialRef.current.uniforms.uColor1.value, {
      r: targetC1.r, g: targetC1.g, b: targetC1.b,
      duration: 1.2, ease: 'power2.out'
    });
    
    gsap.to(materialRef.current.uniforms.uColor2.value, {
      r: targetC2.r, g: targetC2.g, b: targetC2.b,
      duration: 1.2, ease: 'power2.out'
    });
    
    gsap.to(materialRef.current.uniforms.uDistortion, {
      value: theme.dist,
      duration: 1.2, ease: 'power2.out'
    });
  }, [sceneState]);

  useFrame((state) => {
    if (!materialRef.current) return;
    materialRef.current.uniforms.uTime.value = state.clock.elapsedTime;
    
    // Smooth pointer interpolation
    const hf = hfState.current;
    materialRef.current.uniforms.uPointer.value.lerp(new THREE.Vector2(hf.pointer.x, -hf.pointer.y), 0.05);
  });

  return (
    <mesh>
      <planeGeometry args={[2, 2]} />
      <shaderMaterial
        ref={materialRef}
        vertexShader={vertexShader}
        fragmentShader={fragmentShader}
        uniforms={uniforms}
        depthWrite={false}
        depthTest={false}
      />
    </mesh>
  );
}

export default function BackgroundCanvas() {
  const isMobile = typeof window !== 'undefined' && window.matchMedia('(max-width: 768px)').matches;
  const prefersReducedMotion = typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // Mobile / Low power fallback
  if (isMobile || prefersReducedMotion) {
    return <MobileBackgroundFallback />;
  }

  return (
    <div className="fixed inset-0 z-0 pointer-events-none" aria-hidden="true">
      <Canvas
        camera={{ position: [0, 0, 1] }}
        gl={{ antialias: false, powerPreference: 'high-performance' }}
        dpr={[1, 1.5]} // Cap resolution for performance
      >
        <FullScreenPlane />
      </Canvas>
    </div>
  );
}

function MobileBackgroundFallback() {
  const { sceneState } = useSceneStore();
  const theme = SCENE_THEMES[sceneState] || SCENE_THEMES['hero'];
  
  return (
    <div 
      className="fixed inset-0 z-0 pointer-events-none transition-colors duration-[1200ms] ease-out"
      style={{
        background: `linear-gradient(135deg, ${theme.c1} 0%, ${theme.c2} 100%)`
      }}
      aria-hidden="true"
    />
  );
}
