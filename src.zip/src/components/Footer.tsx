import { useRef } from 'react';
import gsap from 'gsap';
import { useGSAP } from '@gsap/react';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function Footer() {
  const containerRef = useRef<HTMLElement>(null);

  useGSAP(() => {
    const mm = gsap.matchMedia();

    mm.add('(min-width: 768px)', () => {
      // Background inversion finale
      gsap.to(containerRef.current, {
        backgroundColor: 'var(--primary)',
        color: 'var(--bg)',
        ease: 'none',
        scrollTrigger: {
          trigger: containerRef.current,
          start: 'top 60%',
          end: 'bottom bottom',
          scrub: true
        }
      });

    gsap.fromTo('.finale-text',
      { y: 100, clipPath: 'polygon(0 0, 100% 0, 100% 0, 0 0)' },
      {
        y: 0, clipPath: 'polygon(0 0, 100% 0, 100% 100%, 0 100%)', duration: 1.5, stagger: 0.1, ease: 'power4.out',
        scrollTrigger: {
          trigger: '.finale-text',
          start: 'top 80%'
        }
      }
    );
    });

    return () => mm.revert();
  }, { scope: containerRef });

  return (
    <footer ref={containerRef} id="contact" className="relative w-full min-h-screen flex flex-col justify-between pt-32 pb-12 px-4 md:px-12 lg:px-24 overflow-hidden transition-colors duration-500">
      <div className="flex-1 flex flex-col justify-center">
        <span className="mono-tiny block mb-12 mix-blend-difference text-white">04 // INITIATE COLLABORATION</span>
        <div className="space-y-[-2vw] md:space-y-[-4vw]">
          <div className="overflow-hidden">
            <h2 className="finale-text text-[15vw] md:text-[18vw] font-black font-display leading-[0.8] tracking-tighter uppercase mix-blend-difference text-white">
              Let's
            </h2>
          </div>
          <div className="overflow-hidden pl-[10vw] md:pl-[20vw]">
            <h2 className="finale-text text-[15vw] md:text-[18vw] font-black font-display leading-[0.8] tracking-tighter uppercase mix-blend-difference text-white">
              Build.
            </h2>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12 border-t-2 border-[var(--bg)] pt-8 mix-blend-difference text-white">
        <div>
          <a href="mailto:448vedantshukla@gmail.com" className="text-2xl md:text-4xl font-black font-display uppercase tracking-tight hover:italic transition-all">
            448vedantshukla@gmail.com
          </a>
        </div>
        <div className="flex flex-col md:flex-row gap-8 md:justify-end font-mono text-sm uppercase font-bold tracking-widest">
          <a href="https://github.com/veha2309" target="_blank" rel="noreferrer" className="hover:line-through transition-all">GitHub</a>
          <a href="https://linkedin.com/in/vedant-shukla-79a6342b1" target="_blank" rel="noreferrer" className="hover:line-through transition-all">LinkedIn</a>
        </div>
      </div>
    </footer>
  );
}
