import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sun, Moon } from 'lucide-react';

export default function HUD({
  isLightMode = false,
  toggleTheme = () => {},
}: {
  isLightMode?: boolean;
  toggleTheme?: () => void;
}) {
  const [scrollProgress, setScrollProgress] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const totalScroll = document.documentElement.scrollHeight - window.innerHeight;
      const currentScroll = window.scrollY;
      setScrollProgress(totalScroll > 0 ? (currentScroll / totalScroll) * 100 : 0);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none z-[80]">
      {/* Top Fixed Scroll Progress Bar */}
      <div className="absolute top-0 left-0 right-0 h-[2px] bg-[var(--outline)]">
        <motion.div
          className="h-full bg-[var(--primary)]"
          style={{ width: `${scrollProgress}%` }}
        />
      </div>

      {/* Top Right: Theme Toggle — shown md+ */}
      <div className="absolute top-8 right-8 pointer-events-auto hidden md:block">
        <motion.button
          onClick={toggleTheme}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          aria-label={isLightMode ? 'Switch to dark theme' : 'Switch to light theme'}
          className="p-3 glass rounded-full text-[var(--text)] hover:text-[var(--primary)] transition-colors border border-[var(--outline)] shadow-sm"
        >
          <AnimatePresence mode="wait">
            {isLightMode ? (
              <motion.div
                key="sun"
                initial={{ opacity: 0, rotate: -90 }}
                animate={{ opacity: 1, rotate: 0 }}
                exit={{ opacity: 0, rotate: 90 }}
                transition={{ duration: 0.2 }}
              >
                <Sun size={18} />
              </motion.div>
            ) : (
              <motion.div
                key="moon"
                initial={{ opacity: 0, rotate: -90 }}
                animate={{ opacity: 1, rotate: 0 }}
                exit={{ opacity: 0, rotate: 90 }}
                transition={{ duration: 0.2 }}
              >
                <Moon size={18} />
              </motion.div>
            )}
          </AnimatePresence>
        </motion.button>
      </div>
    </div>
  );
}
