import Navbar from './components/NavBar';
import Footer from './components/Footer';
import Home from './pages/Home';
import Projects from './pages/Projects';
import Resume from './pages/Resume';
import HUD from './components/HUD';
import Cursor from './components/Cursor';
import Preloader from './components/Preloader';
import SmoothScroll from './components/SmoothScroll';

import { useState, useLayoutEffect, lazy, Suspense } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

import { SceneProvider, useNavigationTheme } from './store/useSceneStore';

const BackgroundCanvas = lazy(() => import('./components/webgl/BackgroundCanvas'));

gsap.registerPlugin(ScrollTrigger);

// An inner component is needed to consume the SceneContext
function AppContent() {
  const [isBooting, setIsBooting] = useState(true);
  const navTheme = useNavigationTheme();

  useLayoutEffect(() => {
    document.documentElement.setAttribute('data-theme', navTheme);
  }, [navTheme]);

  return (
    <SmoothScroll>
      <div 
        className="relative min-h-screen text-[var(--text)] selection:bg-[var(--primary)] selection:text-white overflow-x-hidden transition-colors duration-500"
        onContextMenu={(e) => e.preventDefault()}
      >
        {/* Entry curtain sequence */}
        <Preloader onComplete={() => setIsBooting(false)} />
        
        {/* Custom Contextual Cursor (currently disabled per Phase 1) */}
        <Cursor />

        {/* Persistent Dynamic Background Canvas System */}
        <Suspense fallback={<div className="fixed inset-0 z-0 bg-[var(--bg)]" />}>
          <BackgroundCanvas />
        </Suspense>
        
        {/* Scroll Progress & Theme Control (theme toggle removed since it's dynamic now) */}
        <HUD isLightMode={navTheme === 'light'} toggleTheme={() => {}} />

        {/* Floating Navigation */}
        <Navbar isLightMode={navTheme === 'light'} toggleTheme={() => {}} />

        {/* Main Content Sections */}
        <main aria-hidden={isBooting} className="relative z-10">
          <section id="home">
            <Home />
          </section>
          
          <section id="projects">
            <Projects />
          </section>
          
          <section id="resume">
            <Resume />
          </section>
          
          <Footer />
        </main>
      </div>
    </SmoothScroll>
  );
}

export default function App() {
  return (
    <SceneProvider>
      <AppContent />
    </SceneProvider>
  );
}
