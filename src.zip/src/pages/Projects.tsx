import { useRef } from 'react';
import gsap from 'gsap';
import { useGSAP } from '@gsap/react';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, ArrowDownRight } from 'lucide-react';
import { useSceneStore } from '../store/useSceneStore';
import type { SceneState } from '../store/useSceneStore';

gsap.registerPlugin(ScrollTrigger);

export default function Projects() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { setSceneState } = useSceneStore();

  useGSAP(() => {
    // Setup scene state triggers for the background canvas
    const createSceneTrigger = (selector: string, state: SceneState) => {
      ScrollTrigger.create({
        trigger: selector,
        start: 'top 60%',
        end: 'bottom 40%',
        onEnter: () => setSceneState(state),
        onEnterBack: () => setSceneState(state),
      });
    };

    createSceneTrigger('.scene-finance', 'finance');
    createSceneTrigger('.scene-stock', 'stock');
    createSceneTrigger('.scene-microplastics', 'microplastics');
    createSceneTrigger('.scene-vision', 'vision');

    // General text reveals
    const scenes = gsap.utils.toArray('.project-scene');
    scenes.forEach((scene: any) => {
      const reveals = scene.querySelectorAll('.proj-reveal');
      gsap.from(reveals, {
        y: 40,
        opacity: 0,
        duration: 0.8,
        stagger: 0.1,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: scene,
          start: 'top 75%',
          toggleActions: 'play none none reverse'
        }
      });
    });

  }, { scope: containerRef });

  return (
    <div ref={containerRef} className="w-full relative z-[var(--z-content)] overflow-hidden">
      
      {/* 
        SELECTED WORK INTRODUCTION
      */}
      <section className="w-full min-h-[70svh] flex flex-col justify-center px-6 lg:px-12 py-24">
        <div className="max-w-screen-2xl mx-auto w-full">
          <h2 className="text-[var(--text-fluid-h1)] font-black font-display tracking-tighter uppercase leading-[0.85] text-[var(--text)] mb-8">
            SELECTED<br/>
            <span className="text-[var(--text-muted)]">SYSTEMS</span><br/>
            01—04
          </h2>
          <ArrowDownRight size={48} className="text-[var(--primary)]" />
        </div>
      </section>

      {/* 
        01: FINANCEFLOW - Horizontal Editorial Layout
      */}
      <section className="project-scene scene-finance relative w-full px-6 lg:px-12 py-24 lg:py-32 flex flex-col isolation-isolate overflow-clip">
        <div className="max-w-screen-2xl mx-auto w-full">
          <div className="proj-reveal mb-12">
            <h3 className="text-[var(--text-fluid-h2)] font-black font-display tracking-tighter uppercase leading-[0.9]">FinanceFlow</h3>
          </div>
          
          <div className="flex flex-col lg:flex-row gap-12 lg:gap-24 items-start">
            {/* Main Media 70% */}
            <div className="w-full lg:w-[70%] relative overflow-hidden border-sharp">
              <img src="https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=2564&auto=format&fit=crop" alt="FinanceFlow" className="w-full h-auto aspect-video lg:aspect-[16/10] object-cover" />
            </div>
            
            {/* Content 30% */}
            <div className="w-full lg:w-[30%] flex flex-col pt-4">
              <span className="mono-tiny block mb-4 proj-reveal">01 // Real-Time Ledger</span>
              <p className="font-sans text-base md:text-lg text-[var(--text-muted)] leading-relaxed mb-12 proj-reveal">
                Full-stack financial dashboard utilizing React 19, Node.js, and Socket.io for millisecond-latency trade synchronization across 100+ clients.
              </p>
              
              <div className="grid grid-cols-1 gap-6 mb-12 proj-reveal">
                <div>
                  <span className="mono-tiny block mb-1">ROLE</span>
                  <span className="text-sm font-semibold">Full-Stack Developer</span>
                </div>
                <div>
                  <span className="mono-tiny block mb-1">STACK</span>
                  <span className="text-sm font-semibold">React, Node.js, Socket.io</span>
                </div>
              </div>

              <div className="proj-reveal">
                <a href="https://github.com/veha2309/financeflow" target="_blank" rel="noreferrer" className="link-hard text-sm inline-flex items-center gap-2 text-[var(--primary)] hover:text-white">
                  VIEW CASE STUDY <ArrowRight size={14} />
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 
        02: STOCKPULSE - Dense Media First
      */}
      <section className="project-scene scene-stock relative w-full px-6 lg:px-12 py-24 lg:py-32 flex flex-col isolation-isolate overflow-clip">
        <div className="max-w-screen-2xl mx-auto w-full flex flex-col lg:flex-row gap-12 lg:gap-16 items-center">
          
          <div className="w-full lg:w-[25%] flex flex-col order-2 lg:order-1">
            <span className="mono-tiny block mb-4 proj-reveal text-[var(--primary)]">02 // Mobile Trade</span>
            <h3 className="text-[clamp(2.5rem,4vw,4rem)] font-black font-display tracking-tighter uppercase leading-[0.9] mb-8 proj-reveal">
              StockPulse
            </h3>
            <p className="font-sans text-base text-[var(--text-muted)] leading-relaxed mb-8 proj-reveal">
              High-frequency trading interface built in Flutter, maintaining stable 60fps rendering during peak market volatility.
            </p>
            <div className="proj-reveal mb-8">
              <span className="mono-tiny block mb-1">TECH</span>
              <span className="text-sm font-semibold">Flutter, Dart, Hive DB</span>
            </div>
            <div className="proj-reveal">
              <a href="https://github.com/veha2309/stockpulse" target="_blank" rel="noreferrer" className="link-hard text-sm inline-flex items-center gap-2">
                VIEW REPOSITORY <ArrowRight size={14} />
              </a>
            </div>
          </div>

          <div className="w-full lg:w-[75%] order-1 lg:order-2 relative border-sharp overflow-hidden">
             <img src="https://images.unsplash.com/photo-1550751827-4bd374c3f58b?q=80&w=2670&auto=format&fit=crop" alt="StockPulse" className="w-full h-auto aspect-square lg:aspect-[21/9] object-cover" />
          </div>

        </div>
      </section>

      {/* 
        03: MICROPLASTICS - Organic & Layered
      */}
      <section className="project-scene scene-microplastics relative w-full px-6 lg:px-12 py-24 lg:py-48 flex flex-col isolation-isolate overflow-clip">
        <div className="max-w-screen-2xl mx-auto w-full relative">
          
          <div className="relative z-10 w-full lg:w-[50%] pt-12 lg:pt-0 proj-reveal mb-12 lg:mb-0">
            <span className="mono-tiny block mb-4 text-[#3a5a5c]">03 // IoT & ML</span>
            <h3 className="text-[var(--text-fluid-h2)] font-black font-display tracking-tighter uppercase leading-[0.9] text-gray-900 dark:text-white mb-8">
              Microplastics<br/>Detector
            </h3>
            <p className="font-sans text-lg text-gray-700 dark:text-[var(--text-muted)] leading-relaxed max-w-md mb-8">
              IoT pipeline deploying machine learning models for real-time microplastic concentration analysis in water supplies, achieving 94% accuracy.
            </p>
            <div className="flex gap-8 mb-8">
               <div>
                  <span className="mono-tiny block mb-1">ROLE</span>
                  <span className="text-sm font-semibold text-gray-900 dark:text-white">ML Lead</span>
                </div>
                <div>
                  <span className="mono-tiny block mb-1">STACK</span>
                  <span className="text-sm font-semibold text-gray-900 dark:text-white">Python, TF, RPi</span>
                </div>
            </div>
          </div>

          <div className="w-full lg:w-[70%] lg:absolute lg:top-[-100px] lg:right-0 z-0">
            {/* Organic clip path mask on desktop */}
            <div className="relative w-full aspect-[4/3] lg:aspect-square overflow-hidden rounded-full lg:rounded-[40%_60%_70%_30%/40%_50%_60%_50%] border-sharp">
              <img src="https://images.unsplash.com/photo-1582719471384-894fbb16e074?q=80&w=2564&auto=format&fit=crop" alt="Microscopy" className="w-full h-full object-cover scale-110" />
            </div>
          </div>

        </div>
      </section>

      {/* 
        04: VISION ASSISTANT - Spatial & Directional
      */}
      <section className="project-scene scene-vision relative w-full px-6 lg:px-12 py-24 lg:py-32 flex flex-col isolation-isolate overflow-clip">
        <div className="max-w-screen-2xl mx-auto w-full flex flex-col lg:flex-row-reverse gap-12 items-center">
          
          <div className="w-full lg:w-[60%] relative border-sharp overflow-hidden">
             <img src="https://images.unsplash.com/photo-1678323687332-6a4a982db2e6?q=80&w=2564&auto=format&fit=crop" alt="Vision Assistant" className="w-full h-auto aspect-video object-cover" />
          </div>

          <div className="w-full lg:w-[40%] flex flex-col lg:pr-12">
            <span className="mono-tiny block mb-4 proj-reveal text-[var(--primary)]">04 // AI Context</span>
            <h3 className="text-[var(--text-fluid-h2)] font-black font-display tracking-tighter uppercase leading-[0.9] mb-8 proj-reveal">
              Vision<br/>Assistant
            </h3>
            <p className="font-sans text-lg text-[var(--text-muted)] leading-relaxed mb-8 proj-reveal">
              An intelligent conversational interface processing multi-modal context streams for spatial awareness with sub-2s inference latency.
            </p>
            <div className="proj-reveal mb-8">
              <span className="mono-tiny block mb-1">TECH</span>
              <span className="text-sm font-semibold">Next.js, OpenAI API, WebRTC</span>
            </div>
            <div className="proj-reveal">
              <a href="https://github.com/veha2309/vision_assistant" target="_blank" rel="noreferrer" className="link-hard text-sm inline-flex items-center gap-2">
                VIEW CASE STUDY <ArrowRight size={14} />
              </a>
            </div>
          </div>

        </div>
      </section>

    </div>
  );
}
