import { useRef } from 'react';
import gsap from 'gsap';
import { useGSAP } from '@gsap/react';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useSceneStore } from '../store/useSceneStore';

gsap.registerPlugin(ScrollTrigger);

export default function Home() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { setSceneState } = useSceneStore();

  useGSAP(() => {
    // Setup ScrollTrigger for hero scene state
    ScrollTrigger.create({
      trigger: containerRef.current,
      start: 'top top',
      end: 'bottom 50%',
      onEnter: () => setSceneState('hero'),
      onEnterBack: () => setSceneState('hero'),
    });

    // Monumental intro animation with safe boundaries
    gsap.fromTo('.hero-text-line',
      { y: 150, opacity: 0, clipPath: 'polygon(0 0, 100% 0, 100% 0, 0 0)' },
      { y: 0, opacity: 1, clipPath: 'polygon(0 0, 100% 0, 100% 100%, 0 100%)', duration: 1.5, stagger: 0.1, ease: 'power4.out', delay: 0.2 }
    );
    
    gsap.fromTo('.hero-metadata',
      { opacity: 0, y: 20 },
      { opacity: 1, y: 0, duration: 1, delay: 1.2, ease: 'power3.out' }
    );

    // Hero-to-work connected transition
    gsap.to('.hero-text-block', {
      y: -100,
      opacity: 0,
      ease: 'power2.inOut',
      scrollTrigger: {
        trigger: containerRef.current,
        start: 'top top',
        end: 'bottom top',
        scrub: 0.5
      }
    });

  }, { scope: containerRef });

  return (
    <div ref={containerRef} className="relative w-full min-h-[100svh] flex flex-col justify-end pb-12 md:pb-24 overflow-hidden z-[var(--z-content)] px-6 lg:px-12">
      
      <div className="w-full max-w-screen-2xl mx-auto flex flex-col items-start hero-text-block">
        
        {/* Restrained Metadata */}
        <div className="hero-metadata flex flex-col md:flex-row md:items-center justify-between w-full mb-8 md:mb-16 uppercase font-mono text-xs md:text-sm tracking-widest text-[var(--text-muted)]">
          <span>Vedant Shukla</span>
          <span className="hidden md:inline">Creative Technologist</span>
          <span>Available 2026</span>
        </div>

        {/* Monumental Typography */}
        <div className="overflow-hidden w-full">
          <h1 className="hero-text-line text-[var(--text-fluid-hero-mobile)] md:text-[var(--text-fluid-hero)] font-black font-display text-[var(--text)] leading-[0.85] tracking-tighter uppercase m-0 p-0 text-left">
            I BUILD
          </h1>
        </div>
        <div className="overflow-hidden w-full">
          <h1 className="hero-text-line text-[var(--text-fluid-hero-mobile)] md:text-[var(--text-fluid-hero)] font-black font-display text-[var(--text)] leading-[0.85] tracking-tighter uppercase m-0 p-0 text-left">
            SYSTEMS
          </h1>
        </div>
        <div className="overflow-hidden w-full text-[var(--text-muted)]">
          <h1 className="hero-text-line text-[var(--text-fluid-hero-mobile)] md:text-[var(--text-fluid-hero)] font-black font-display leading-[0.85] tracking-tighter uppercase m-0 p-0 text-left">
            THAT SEE,
          </h1>
        </div>
        <div className="overflow-hidden w-full">
          <h1 className="hero-text-line text-[var(--text-fluid-hero-mobile)] md:text-[var(--text-fluid-hero)] font-black font-display text-[var(--text)] leading-[0.85] tracking-tighter uppercase m-0 p-0 text-left">
            THINK & MOVE.
          </h1>
        </div>
      </div>
      
    </div>
  );
}
