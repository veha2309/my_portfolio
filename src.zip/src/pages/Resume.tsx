import { useRef } from 'react';
import gsap from 'gsap';
import { useGSAP } from '@gsap/react';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { experience } from '../data/experience';
import { skills } from '../data/skills';

import { useSceneStore } from '../store/useSceneStore';

gsap.registerPlugin(ScrollTrigger);

export default function Resume() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { setSceneState } = useSceneStore();

  useGSAP(() => {
    ScrollTrigger.create({
      trigger: containerRef.current,
      start: 'top 50%',
      end: 'bottom 50%',
      onEnter: () => setSceneState('resume'),
      onEnterBack: () => setSceneState('resume'),
    });

    const lines = gsap.utils.toArray('.dossier-line');
    lines.forEach((line: any) => {
      gsap.fromTo(line, 
        { scaleX: 0, transformOrigin: 'left' },
        { scaleX: 1, duration: 1, ease: 'power4.out',
          scrollTrigger: {
            trigger: line,
            start: 'top 90%'
          }
        }
      );
    });

    const items = gsap.utils.toArray('.dossier-item');
    items.forEach((item: any) => {
      gsap.fromTo(item,
        { opacity: 0, y: 30 },
        { opacity: 1, y: 0, duration: 1, ease: 'power3.out',
          scrollTrigger: {
            trigger: item,
            start: 'top 90%'
          }
        }
      );
    });
  }, { scope: containerRef });

  return (
    <div ref={containerRef} className="w-full bg-[var(--bg)] pt-24 pb-32">
      <div className="px-4 md:px-12 lg:px-24 mb-24">
        <h2 className="text-[10vw] font-black font-display tracking-tighter leading-[0.85] uppercase">
          Dossier
        </h2>
      </div>

      <div className="px-4 md:px-12 lg:px-24 grid lg:grid-cols-12 gap-16 lg:gap-24">
        
        {/* Left Column: Chronology */}
        <div className="lg:col-span-8">
          <span className="mono-tiny block mb-8 text-[var(--primary)]">01 // CHRONOLOGY</span>
          
          <div className="space-y-16">
            {experience.map((job, i) => (
              <div key={i} className="dossier-item relative pt-8">
                <div className="dossier-line absolute top-0 left-0 w-full h-[1px] bg-[var(--text)]" />
                <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                  <div className="md:col-span-1">
                    <span className="text-xl md:text-2xl font-black font-display">{job.period.split(' – ')[0]}</span>
                    <span className="mono-tiny block mt-2 opacity-50">{job.period}</span>
                  </div>
                  <div className="md:col-span-3 space-y-4">
                    <h3 className="text-3xl md:text-4xl font-bold font-display uppercase tracking-tight leading-[0.9]">
                      {job.role}
                    </h3>
                    <p className="font-mono text-sm uppercase text-[var(--primary)]">{job.company}</p>
                    <ul className="space-y-3 mt-6">
                      {job.responsibilities.map((r, idx) => (
                        <li key={idx} className="font-sans text-sm md:text-base leading-relaxed text-[var(--text-muted)]">
                          {r}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Column: Capabilities */}
        <div className="lg:col-span-4">
          <span className="mono-tiny block mb-8 text-[var(--primary)]">02 // CAPABILITIES</span>
          
          <div className="space-y-12">
            {Object.entries(skills).map(([category, items], i) => (
              <div key={i} className="dossier-item">
                <div className="dossier-line w-full h-[1px] bg-[var(--text)] mb-4" />
                <h4 className="text-lg font-bold font-display uppercase tracking-tight mb-4">{category}</h4>
                <p className="font-mono text-sm leading-relaxed text-[var(--text-muted)] uppercase tracking-wider break-words">
                  {items.join(', ')}
                </p>
              </div>
            ))}
            
            {/* Academic Credentials */}
            <div className="dossier-item pt-12">
              <span className="mono-tiny block mb-8 text-[var(--primary)]">03 // ACCREDITATION</span>
              <div className="dossier-line w-full h-[1px] bg-[var(--text)] mb-4" />
              <h4 className="text-2xl font-bold font-display uppercase tracking-tight mb-2">BTech CSE</h4>
              <p className="font-mono text-sm uppercase text-[var(--text-muted)] mb-4">Dr. Akhilesh Das Gupta ITM</p>
              <span className="inline-block px-3 py-1 bg-[var(--primary)] text-[var(--bg)] font-bold text-xs font-mono">CGPA: 7.8</span>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
